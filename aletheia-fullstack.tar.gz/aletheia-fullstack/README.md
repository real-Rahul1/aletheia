# Aletheia — Agent37 full-stack app

Aletheia media-forensics interface mirrored from the supplied Netlify website, plus a same-origin Node API gateway for the live Aletheia AI forensic and Sepolia blockchain backend.

## Features

- Responsive landing page, drag-and-drop analyzer, image/video/audio uploads, URL analysis, results/history, and blockchain registration/status.
- Same-origin `/api` proxy avoids browser CORS issues and keeps the upstream service configurable.
- Blockchain certificate and public record lookup at `/verify.html?id=ALT-…` or `/verify/ALT-…`.
- File-integrity flow computes SHA-256 in the browser and checks the blockchain record without uploading the media file to the blockchain. “No record” means not registered, not fake.
- Analysis history persisted locally in `data/analysis.json` (bounded to latest 500 records).
- `/api/history`, `/api/health`; 50 MB upload size cap by default.

## Run

Node.js 20 or later, no npm dependencies required.

```sh
npm test
npm start
```

The server listens on `PORT` (default 3000). Set `ALETHEIA_BACKEND_URL` to use a different compatible backend (default `https://aletheia-blockchain.onrender.com`). The upstream service holds the AI vendor API keys and blockchain RPC/contract credentials; none are embedded in this app.

The included API backend is a gateway backed by that live upstream. The browser UI, API proxy, and history store are deployed together; model inference and Sepolia transactions remain provided by the configured upstream service. The server does not pretend to run AI inference locally.
