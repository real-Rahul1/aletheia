'use strict';
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { URL } = require('node:url');

const ROOT = __dirname;
const PUBLIC = path.join(ROOT, 'public');
const DB_DIR = path.join(ROOT, 'data');
const DB_FILE = path.join(DB_DIR, 'analysis.json');
const PORT = Number(process.env.PORT || 3000);
const BACKEND_URL = (process.env.ALETHEIA_BACKEND_URL || 'https://aletheia-blockchain.onrender.com').replace(/\/$/, '');
const MAX_UPLOAD = Number(process.env.MAX_UPLOAD_BYTES || 50 * 1024 * 1024);
const MIME = { '.html':'text/html; charset=utf-8', '.css':'text/css; charset=utf-8', '.js':'text/javascript; charset=utf-8', '.json':'application/json; charset=utf-8', '.svg':'image/svg+xml', '.jpg':'image/jpeg', '.jpeg':'image/jpeg', '.png':'image/png', '.webp':'image/webp', '.ico':'image/x-icon', '.mp4':'video/mp4', '.pdf':'application/pdf' };

function readDb() {
  try { const parsed = JSON.parse(fs.readFileSync(DB_FILE, 'utf8')); return Array.isArray(parsed) ? parsed : []; }
  catch { return []; }
}
let dbWriteQueue = Promise.resolve();
function saveAnalysis(analysis) {
  const operation = dbWriteQueue.then(() => {
    const db=readDb(); db.push(analysis); if(db.length>500) db.splice(0,db.length-500); writeDb(db);
  });
  dbWriteQueue = operation.catch(() => {});
  return operation;
}
function writeDb(db) {
  fs.mkdirSync(DB_DIR, { recursive: true });
  const temp = `${DB_FILE}.${process.pid}.tmp`;
  fs.writeFileSync(temp, JSON.stringify(db, null, 2), { mode: 0o600 });
  fs.renameSync(temp, DB_FILE);
}
function json(res, status, body) {
  const data = Buffer.from(JSON.stringify(body));
  res.writeHead(status, { 'Content-Type':'application/json; charset=utf-8', 'Content-Length':data.length, 'Cache-Control':'no-store', 'X-Content-Type-Options':'nosniff' });
  res.end(data);
}
function collect(req, max = MAX_UPLOAD) {
  return new Promise((resolve, reject) => {
    const parts = []; let size = 0;
    req.on('data', chunk => { size += chunk.length; if (size > max) { reject(Object.assign(new Error('Upload exceeds 50 MB limit'), { status:413 })); req.destroy(); return; } parts.push(chunk); });
    req.on('end', () => resolve(Buffer.concat(parts)));
    req.on('error', reject);
  });
}
async function backendFetch(apiPath, options = {}) {
  const response = await fetch(`${BACKEND_URL}${apiPath}`, { ...options, redirect:'error', signal: options.signal || AbortSignal.timeout(120000) });
  const text = await response.text();
  let data; try { data = text ? JSON.parse(text) : {}; } catch { data = { error: text.slice(0, 500) || response.statusText }; }
  return { status: response.status, data };
}
function parseMultipart(buf, contentType) {
  const match = /boundary=(?:"([^"]+)"|([^;]+))/i.exec(contentType || '');
  if (!match) throw Object.assign(new Error('Expected multipart form upload'), { status:400 });
  const boundary = Buffer.from(`--${match[1] || match[2]}`);
  let cursor = 0;
  const fields = {}; 
  while (true) {
    const start = buf.indexOf(boundary, cursor); if (start < 0) break;
    let partStart = start + boundary.length;
    if (buf.subarray(partStart, partStart + 2).toString() === '--') break;
    if (buf.subarray(partStart, partStart + 2).toString() === '\r\n') partStart += 2;
    const headerEnd = buf.indexOf(Buffer.from('\r\n\r\n'), partStart); if (headerEnd < 0) break;
    const headers = buf.subarray(partStart, headerEnd).toString('utf8');
    const next = buf.indexOf(boundary, headerEnd + 4); if (next < 0) break;
    let end = next; if (buf.subarray(end - 2, end).toString() === '\r\n') end -= 2;
    const body = buf.subarray(headerEnd + 4, end);
    const dispo = /content-disposition:\s*form-data;([^\r\n]+)/i.exec(headers)?.[1] || '';
    const name = /name="([^"]+)"/i.exec(dispo)?.[1];
    const filename = /filename="([^"]*)"/i.exec(dispo)?.[1] || 'media.bin';
    const type = /content-type:\s*([^\r\n]+)/i.exec(headers)?.[1]?.trim() || 'application/octet-stream';
    if (name === 'image' || name === 'file' || name === 'media') fields[name] = { body, filename: path.basename(filename).slice(0,255), type };
    else if (name) fields[name] = body.toString('utf8');
    cursor = next;
  }
  return { file:fields.image || fields.file || fields.media || null, fields };
}
function routeStatic(req, res, pathname) {
  let decoded;
  try { decoded = decodeURIComponent(pathname); } catch { json(res, 400, { error:'Invalid path' }); return; }
  if (decoded === '/verify' || /^\/verify\/[A-Za-z0-9_-]+$/.test(decoded)) decoded = '/verify.html';
  if (decoded === '/documentation') decoded = '/documentation.html';
  if (decoded === '/') decoded = '/index.html';
  const file = path.resolve(PUBLIC, `.${decoded}`);
  if (!file.startsWith(`${PUBLIC}${path.sep}`) || !fs.existsSync(file) || !fs.statSync(file).isFile()) { json(res,404,{error:'Not found'}); return; }
  const ext = path.extname(file).toLowerCase();
  res.writeHead(200, { 'Content-Type':MIME[ext] || 'application/octet-stream', 'Content-Length':fs.statSync(file).size, 'X-Content-Type-Options':'nosniff', 'Referrer-Policy':'strict-origin-when-cross-origin' });
  fs.createReadStream(file).pipe(res);
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  const pathname = url.pathname;
  if (req.method === 'OPTIONS') { res.writeHead(204, { 'Access-Control-Allow-Origin':'*', 'Access-Control-Allow-Methods':'GET,POST,OPTIONS', 'Access-Control-Allow-Headers':'Content-Type' }); return res.end(); }
  try {
    if (req.method === 'GET' && pathname === '/api/health') {
      let service = { status:'unknown' };
      try { const r = await backendFetch('/api/health', { signal:AbortSignal.timeout(10000) }); service = r.data; }
      catch (e) { service = { status:'unreachable', message:e.message }; }
      return json(res, 200, { status:'ok', app:'Aletheia', backend:service, persistence:'local-json' });
    }
    if (req.method === 'GET' && pathname === '/api/history') {
      return json(res, 200, { analyses:readDb().slice(-100).reverse() });
    }
    if (req.method === 'POST' && pathname === '/api/analyze/upload') {
      const raw = await collect(req);
      const parsed = parseMultipart(raw, req.headers['content-type']);
      const file = parsed.file;
      if (!file || !file.body.length) return json(res,400,{error:'No image uploaded'});
      const form = new FormData();
      form.append('image', new Blob([file.body], { type:file.type }), file.filename);
      const result = await backendFetch('/api/analyze/upload', { method:'POST', body:form });
      if (result.status < 200 || result.status >= 300) return json(res,result.status,result.data);
      const analysis = { id:crypto.randomUUID(), filename:file.filename, createdAt:new Date().toISOString(), ...result.data };
      await saveAnalysis(analysis);
      return json(res,200,result.data);
    }
    if (req.method === 'POST' && pathname === '/api/analyze/url') {
      const raw = await collect(req, 64*1024); let payload;
      try { payload=JSON.parse(raw.toString('utf8')); } catch { return json(res,400,{error:'Invalid JSON body'}); }
      if (typeof payload.url !== 'string' || payload.url.length > 2048) return json(res,400,{error:'Please provide a valid media URL'});
      let mediaUrl; try { mediaUrl=new URL(payload.url); } catch { return json(res,400,{error:'Please provide a valid media URL'}); }
      if (!['http:','https:'].includes(mediaUrl.protocol) || mediaUrl.username || mediaUrl.password) return json(res,400,{error:'Only public HTTP or HTTPS media URLs are supported'});
      const dns = require('node:dns').promises;
      const net = require('node:net');
      const isPublicAddress = (address) => {
        if (net.isIPv4(address)) {
          const octets=address.split('.').map(Number);
          return !(octets[0]===10 || octets[0]===127 || octets[0]===0 || (octets[0]===169&&octets[1]===254) || (octets[0]===172&&octets[1]>=16&&octets[1]<=31) || (octets[0]===192&&octets[1]===168) || octets[0]>=224);
        }
        if (net.isIPv6(address)) {
          const lower=address.toLowerCase();
          if (lower==='::1' || lower==='::' || lower.startsWith('fc') || lower.startsWith('fd') || lower.startsWith('fe8') || lower.startsWith('fe9') || lower.startsWith('fea') || lower.startsWith('feb')) return false;
          const mapped=lower.match(/::ffff:(\d+\.\d+\.\d+\.\d+)$/);
          return mapped ? isPublicAddress(mapped[1]) : true;
        }
        return false;
      };
      let addresses;
      if (net.isIP(mediaUrl.hostname)) addresses=[{address:mediaUrl.hostname}];
      else { try { addresses=await dns.lookup(mediaUrl.hostname,{all:true,verbatim:true}); } catch { return json(res,400,{error:'Media host could not be resolved'}); } }
      if (!addresses.length || addresses.some(entry=>!isPublicAddress(entry.address))) return json(res,400,{error:'Only publicly reachable media URLs are supported'});
      const upstream=await backendFetch('/api/analyze/url',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({url:mediaUrl.toString()})});
      if(upstream.status<200||upstream.status>=300) return json(res,upstream.status,upstream.data);
      const analysis={id:crypto.randomUUID(),filename:mediaUrl.hostname+mediaUrl.pathname,createdAt:new Date().toISOString(),...upstream.data};
      await saveAnalysis(analysis);
      return json(res,200,upstream.data);
    }
    if (pathname.startsWith('/api/blockchain/')) {
      const apiPath=pathname+url.search;
      if (req.method === 'GET' && pathname === '/api/blockchain/verify') {
        const hash=url.searchParams.get('mediaHash');
        if (!/^0x[0-9a-f]{64}$/i.test(hash || '')) return json(res,400,{error:'Provide a valid SHA-256 mediaHash'});
        const verificationId=url.searchParams.get('verificationId');
        if (verificationId) {
          const found=await backendFetch(`/api/blockchain/record/${encodeURIComponent(verificationId)}`);
          if (found.status===404) return json(res,200,{status:'no_record',registered:false,mediaHash:hash,message:'No record found for that Verification ID.'});
          if (found.status!==200) return json(res,found.status,found.data);
          const record=found.data.record;
          const matches=record?.mediaHash?.toLowerCase()===hash.toLowerCase();
          return json(res,200,{status:matches?'verified':'mismatch',registered:matches,mediaHash:hash,record,demoMode:found.data.demoMode,message:matches?'The file fingerprint matches this blockchain record.':'The file does not match the selected blockchain record.'});
        }
        const checked=await backendFetch(`/api/blockchain/status/${encodeURIComponent(hash)}`);
        if(checked.status!==200) return json(res,checked.status,checked.data);
        let record=null;
        if(checked.data.registered){const id=`ALT-${hash.slice(2,10).toUpperCase()}`;const found=await backendFetch(`/api/blockchain/record/${id}`);if(found.status===200)record=found.data.record;}
        return json(res,200,{...checked.data,mediaHash:hash,record,status:checked.data.registered?'verified':'no_record',message:checked.data.registered?'The file fingerprint matches a blockchain record.':'No blockchain record exists for this file fingerprint.'});
      }
      if (req.method === 'GET' && /^\/api\/blockchain\/(?:status|record)\//.test(pathname)) {
        const upstream=await backendFetch(apiPath); return json(res,upstream.status,upstream.data);
      }
      if (req.method === 'POST' && pathname === '/api/blockchain/verify') {
        const raw = await collect(req);
        const parsed = parseMultipart(raw, req.headers['content-type']);
        const file = parsed.file;
        if (!file || !file.body.length) return json(res,400,{error:'No file uploaded'});
        const hash='0x'+crypto.createHash('sha256').update(file.body).digest('hex');
        const verificationId = parsed.fields.verificationId || '';
        if (verificationId) {
          const recordResult = await backendFetch(`/api/blockchain/record/${encodeURIComponent(verificationId)}`);
          if (recordResult.status === 200) {
            const record = recordResult.data.record;
            const matches = record?.mediaHash?.replace(/^0x/i,'').toLowerCase() === hash.slice(2).toLowerCase();
            return json(res,200,{status:matches?'verified':'mismatch',registered:matches,mediaHash:hash,record:record || null,demoMode:recordResult.data.demoMode,message:matches?'The file fingerprint matches this blockchain record.':'The file does not match the selected blockchain record.'});
          }
          return json(res,200,{status:'no_record',registered:false,mediaHash:hash,message:'No record found for that Verification ID.'});
        }
        const verifyPath=`/api/blockchain/status/${hash}`;
        const upstream=await backendFetch(verifyPath);
        if(upstream.status<200||upstream.status>=300) return json(res,upstream.status,upstream.data);
        let record = null;
        if (upstream.data.registered) {
          const verificationIdFromHash=`ALT-${hash.slice(2,10).toUpperCase()}`;
          const found=await backendFetch(`/api/blockchain/record/${verificationIdFromHash}`);
          if(found.status===200) record=found.data.record;
        }
        const result={...upstream.data,mediaHash:hash,record,status:upstream.data.registered?'verified':'no_record',message:upstream.data.registered?'The file fingerprint matches a blockchain record.':'No blockchain record exists for this file fingerprint.'};
        return json(res,200,result);
      }
      if (req.method === 'POST' && pathname === '/api/blockchain/register') {
        const raw=await collect(req,256*1024); let payload;
        try{payload=JSON.parse(raw.toString('utf8'));}catch{return json(res,400,{error:{code:'BAD_REQUEST',message:'Invalid JSON body'}});}
        const upstream=await backendFetch(pathname,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});
        return json(res,upstream.status,upstream.data);
      }
    }
    if (req.method === 'GET' || req.method === 'HEAD') return routeStatic(req,res,pathname);
    return json(res,404,{error:'Not found'});
  } catch (error) {
    if (res.headersSent || res.destroyed) return;
    const status=error.status || 502;
    json(res,status,{error:status===413?'Upload exceeds the configured size limit':(error.message || 'Service unavailable')});
  }
});
server.listen(PORT,'0.0.0.0',()=>console.log(`Aletheia listening on 0.0.0.0:${PORT}; backend=${BACKEND_URL}`));
