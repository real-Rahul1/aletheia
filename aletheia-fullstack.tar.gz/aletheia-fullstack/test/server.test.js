'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { spawn } = require('node:child_process');
const path = require('node:path');
const http = require('node:http');

const project = path.resolve(__dirname, '..');
let server;
let backend;
let base;

test.before(async () => {
  backend=http.createServer((req,res)=>{
    res.setHeader('content-type','application/json');
    if(req.url==='/api/health') return res.end(JSON.stringify({status:'ok'}));
    if(req.url.startsWith('/api/blockchain/status/')) return res.end(JSON.stringify({demoMode:false,registered:false}));
    if(req.url.startsWith('/api/blockchain/record/')) {res.statusCode=404; return res.end(JSON.stringify({error:{code:'NOT_FOUND'}}));}
    res.statusCode=404; res.end(JSON.stringify({error:'not found'}));
  });
  await new Promise(resolve=>backend.listen(0,'127.0.0.1',resolve));
  const backendUrl=`http://127.0.0.1:${backend.address().port}`;
  const port = 31000 + Math.floor(Math.random() * 20000);
  server = spawn(process.execPath, ['server.js'], { cwd:project, env:{...process.env,PORT:String(port),ALETHEIA_BACKEND_URL:backendUrl} , stdio:'ignore' });
  base = `http://127.0.0.1:${port}`;
  for (let i=0;i<50;i++) {
    try { const r=await fetch(`${base}/`); if(r.status===200) return; } catch {}
    await new Promise(resolve=>setTimeout(resolve,100));
  }
  throw new Error('Aletheia server did not start');
});
test.after(()=>{server?.kill('SIGTERM');backend?.close();});

test('serves the complete landing page and application assets', async()=>{
  const page=await fetch(`${base}/`);
  assert.equal(page.status,200);
  assert.match(await page.text(),/ALETHEIA/);
  const js=await fetch(`${base}/app.js`);
  assert.equal(js.status,200);
  assert.match(await js.text(),/\/api\/analyze\/upload/);
});

test('health endpoint reports the upstream service', async()=>{
  const response=await fetch(`${base}/api/health`);
  const data=await response.json();
  assert.equal(response.status,200);
  assert.equal(data.status,'ok');
  assert.equal(data.backend.status,'ok');
});

test('routes verification and documentation pages', async()=>{
  const verify=await fetch(`${base}/verify/ALT-12345678`);
  assert.equal(verify.status,200);
  assert.match(await verify.text(),/Verify a/);
  const docs=await fetch(`${base}/documentation`);
  assert.equal(docs.status,200);
  assert.match(await docs.text(),/Evidence Report/);
});

test('validates URL payloads and blocks private-network URL access', async()=>{
  for (const url of ['javascript:alert(1)','http://127.0.0.1/private','http://10.0.0.1/a','https://user:pass@example.com/a']) {
    const response=await fetch(`${base}/api/analyze/url`,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({url})});
    assert.equal(response.status,400,url);
  }
});

test('accepts multipart file upload for blockchain integrity checking', async()=>{
  const form=new FormData();
  form.append('media',new Blob(['sample media bytes'],{type:'image/png'}),'sample.png');
  const response=await fetch(`${base}/api/blockchain/verify`,{method:'POST',body:form});
  assert.equal(response.status,200);
  const data=await response.json();
  assert.equal(data.status,'no_record');
  assert.equal(data.mediaHash,'0x'+require('node:crypto').createHash('sha256').update('sample media bytes').digest('hex'));
});

test('does not write history when backend health is not an analysis', async()=>{
  const response=await fetch(`${base}/api/history`);
  assert.equal(response.status,200);
  assert.deepEqual((await response.json()).analyses,[]);
});
